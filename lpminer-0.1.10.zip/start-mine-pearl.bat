@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "POOL=stratum+tcp://pearl-eu1.luckypool.io:3360"
set "WALLET=prl1pqvgnf4lwqrxy8yttrlh3azedrwagxnvs8kej8vnzuc2h4je5drvsfr4079"
set "WORKER=TEST"
set "RESTART_DELAY=5"

:restart
echo [%DATE% %TIME%] starting lpminer pearl...
lpminer.exe --algo pearl --pool %POOL% --wallet %WALLET% --worker %WORKER%
set "RC=%ERRORLEVEL%"
echo [%DATE% %TIME%] lpminer exited with code !RC!. Restarting in %RESTART_DELAY% seconds...
timeout /t %RESTART_DELAY% /nobreak >nul
goto restart
